THIS README CONTAINS SOME IMPORTANT INFORMATION REGARDING ASSIGNMENTS:

set environment variable according to where you want to create folders. by default i have set it to "C:\FOLDER\" you can change it for your desktop while running for your desktop, dont forget the "\" in the end. keep same environment variable for all 5 assignments.

Assignment 1: If environment variable is set properly then this process should run without issues.

Assignment 2: Here you have to give your gmail id and gmail password as startup parameter, also make sure that you enable "Allow less secure access" in security tab of your google account.
in case you have different email service provider then you would have to change POP3/SMTP server and port in "Configure" stage. 

Assignment 3: If environment variable is set properly then this process should run without issues.

Assignment 4: Here you can create a excel workbook(s) in "Opened" with a single sheet but all column headers should be exactly same as "final.xlsx" in Source files in "added" folder. These newly created excel workbook(s) will be updated in "Completed\report\final.xlsx"

Assignment 5: Here you have to specify path to "iexplore.exe" in application modeller of object studio, also you have to place "CurrencyConversion.xlsx" in "Completed" folder other wise it will throw an exception and information about that exception will be a file called "Errorlog.txt".